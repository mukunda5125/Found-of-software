package main;
import javax.swing.*; 

public class SimpleGUI{

    public static void main(String[] args) {
    
        JFrame frame = new JFrame("My First GUI");

        frame.setSize(300, 200);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

               JLabel label = new JLabel("Hello, this is my first GUI!", SwingConstants.CENTER);

        
        JButton button = new JButton("Click Me!");
       frame.add(label, "North");  
        frame.add(button, "South"); 
         frame.setVisible(true);
    }
}
